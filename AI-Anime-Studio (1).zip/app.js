function generateImage() {
  const prompt = document.getElementById('prompt').value;
  const output = document.getElementById('outputImage');
  const status = document.getElementById('status');
  if (!prompt.trim()) {
    status.textContent = 'Please enter a description first!';
    return;
  }
  status.textContent = 'Generating your anime scene...';
  setTimeout(() => {
    output.src = 'https://placehold.co/600x400/8f5eff/ffffff?text=AI+Anime+Scene';
    status.textContent = `Result for: "${prompt}"`;
  }, 2000);
}
