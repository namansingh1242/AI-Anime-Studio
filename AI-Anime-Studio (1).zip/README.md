# AI Anime Studio

A futuristic cyberpunk-themed demo website for AI-powered anime scene generation.

## 🚀 How to Deploy
1. Upload this folder to your GitHub repo (AI-Anime-Studio)
2. Go to [Vercel](https://vercel.com)
3. Import your repo and click **Deploy**
4. Your site will go live at `https://ai-anime-studio.vercel.app`

Enjoy creating futuristic anime visuals!
